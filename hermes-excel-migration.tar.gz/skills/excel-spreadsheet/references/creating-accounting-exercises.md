# Creating Accounting Practice Exercises

## Pattern for Multi-Sheet Accounting Excel Files

When creating comprehensive accounting exercises, follow this structure:

### Minimum 12-16 Sheets:
1. **Daftar Akun** (Chart of Accounts) — Account codes, names, categories, balance types
2. **Jurnal Q1-Q4** (General Journal) — Quarterly transaction entries
3. **Buku Besar Aset/Kewajiban/Ekuitas/Pendapatan/Beban** (Ledger by category)
4. **Trial Balance** (Neraca Saldo) — Pre-adjustment balances
5. **Jurnal Penyesuaian** (Adjusting Entries) — Depreciation, accruals, deferrals
6. **TB Setelah Penyesuaian** (Adjusted Trial Balance)
7. **Laba Rugi** (Income Statement) — Revenue - Expenses = Net Income
8. **Neraca** (Balance Sheet) — Assets = Liabilities + Equity
9. **Petunjuk Audit** (Audit Guide) — Instructions for the auditor

### Each Sheet Minimum 100 Rows:
- Use padding with analysis notes, audit checklists, descriptions
- Add "CATATAN AUDIT" sections with verification procedures
- Include materiality thresholds, red flags, quality criteria

### Intentional Errors for Audit Practice:
1. **Debit ≠ Kredit** in single transaction (e.g., debit 80M, credit 75M)
2. **Missing pair** — only debit entry, no credit (or vice versa)
3. **Typo in amount** — 48M instead of 4.8M
4. **Swapped Debit/Credit** in Trial Balance
5. **Negative Owner's Equity** — should be positive
6. **Missing transactions** — not recorded in Ledger
7. **Balance Sheet not balanced** — Assets ≠ Liabilities + Equity

### Openpyxl Styling Pattern:
```python
header_font = Font(bold=True, size=11, color="FFFFFF")
header_fill = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
subheader_font = Font(bold=True, size=10, color="1F4E79")
subheader_fill = PatternFill(start_color="D6E4F0", end_color="D6E4F0", fill_type="solid")
currency_fmt = '#,##0'
thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), 
                     top=Side(style='thin'), bottom=Side(style='thin'))
```

### Venv Setup for Excel Creation:
```bash
sudo apt install -y python3-pip python3-venv
python3 -m venv ~/accounting-practice/venv
source ~/accounting-practice/venv/bin/activate
pip install openpyxl pandas
```

## Downloading Accounting Files from GitHub

### API Search:
```bash
curl -s "https://api.github.com/search/repositories?q=accounting+excel+journal+ledger&per_page=10"
```

### Download Pattern:
```bash
curl -sL "https://raw.githubusercontent.com/{owner}/{repo}/main/{filename}" -o "output.xlsx"
# Use URL encoding for spaces: %20
```

### Known Good Repos:
- `mBrownepr1/excel-accounting-cycle` — 7 sheets, complete accounting cycle
- `saqibsahto/Automated-Bookkeeping-System-Excel` — 6 sheets, with validation
- `sadhanasrinivas/Accounting-Bookkeeping` — Journal + Ledger + Trial Balance with formulas

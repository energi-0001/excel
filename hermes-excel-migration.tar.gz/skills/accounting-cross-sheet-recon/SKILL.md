---
name: accounting-cross-sheet-recon
description: "Rekonsiliasi cross-sheet untuk laporan keuangan multi-sheet. Deteksi selisih, lacak sumber selisih ke baris/transaksi spesifik, rekonsiliasi otomatis."
version: 1.0.0
metadata:
  hermes:
    tags: [accounting, audit, reconciliation, cross-sheet, balance]
    related_skills: [excel-spreadsheet]
---

# Accounting Cross-Sheet Reconciliation

Skill khusus untuk menemukan dan melacak selisih antar sheet di laporan keuangan Excel.

## Cara Menggunakan

```
/skill accounting-cross-sheet-recon

"rekon buku_besar.xlsx, cari semua selisih antar sheet"
"cross-check sheet Jurnal vs Buku Besar, tampilkan transaksi penyebab selisih"
"rekonsiliasi semua sheet, grouping by No Akun"
"kenapa Neraca dan Trial Balance selisih 150.000? lacak sumbernya"
"bandingkan saldo per akun di semua sheet"
```

---

## Metode Pengecekan (5 Level)

### Level 1: Quick Sum Comparison
Membandingkan total numerik per sheet → langsung tahu sheet mana yang selisih.

```
Sheet            Total          Status
──────────────────────────────────────
Jurnal         450,000,000        ✓
Buku Besar     449,850,000        ✗ (-150,000 vs Jurnal)
Neraca       1,250,000,000        ✓
Laba Rugi      125,000,000        ✓
Trial Balance  449,850,000        ✗ (-150,000 vs Jurnal)
```

### Level 2: Account-Level Matching
Grouping per No Akun / Kode Rekening di setiap sheet, lalu bandingkan.

```
No Akun    Jurnal         Buku Besar      Selisih
─────────────────────────────────────────────────
101       50,000,000      50,000,000            0
102       75,000,000      75,000,000            0
103      100,000,000      99,850,000     -150,000  ← MASALAH!
104       25,000,000      25,000,000            0
```

### Level 3: Transaction-Level Tracing
Untuk akun yang selisih, lacak setiap transaksi yang membentuk saldo.

```
Sheet Jurnal - Akun 103:
  #45  01/06  Penjualan Tunai      50,000,000
  #67  05/06  Transfer Masuk       30,000,000
  #89  10/06  Pelunasan Piutang    20,000,000
  TOTAL                            100,000,000

Sheet Buku Besar - Akun 103:
  #45  01/06  Penjualan Tunai      50,000,000  ✓
  #67  05/06  Transfer Masuk       30,000,000  ✓
  #89  10/06  Pelunasan Piutang    19,850,000  ✗ NILAI BERBEDA!
  TOTAL                             99,850,000

SELISIH: 150,000 — baris #89 berbeda (Jurnal: 20,000,000 vs BB: 19,850,000)
```

### Level 4: Missing/Extra Transactions
Mendeteksi transaksi yang ada di satu sheet tapi tidak ada di sheet lain.

```
HANYA ADA DI JURNAL (tidak ada di Buku Besar):
  #112  15/06  Koreksi Bank         5,000,000  ← BELUM DIBUKUKAN

HANYA ADA DI BUKU BESAR (tidak ada di Jurnal):
  #201  18/06  Beban Admin          3,500,000  ← TANPA JURNAL
```

### Level 5: Period Opening-Closing Bridge
Memastikan Saldo Awal + Mutasi = Saldo Akhir per akun.

```
Akun 103 - Kas:
  Saldo Awal (1 Juni):     200,000,000
  + Total Debit:            50,000,000
  - Total Kredit:           30,000,000
  = Seharusnya:            220,000,000
  Saldo Akhir tercatat:    220,150,000
  SELISIH:                      150,000  ← tidak cocok
```

---

## Pola Selisih yang Umum Terdeteksi

| Pola | Penyebab Umum | Cara Deteksi |
|------|--------------|--------------|
| Selisih tepat 1 digit beda | Typo input (500rb → 50rb) | Level 3 |
| Selisih = 1 transaksi utuh | Transaksi belum dibukukan di sheet lain | Level 4 |
| Selisih kecil tidak bulat | Pembulatan atau partial posting | Level 3 + toleransi |
| Saldo awal tidak match | Closing period sebelumnya salah | Level 5 |
| Selisih = 2x lipat | Double posting di satu sheet | Level 4 duplikat |
| Selisih di banyak akun | Kesalahan sistematis (kurs, alokasi) | Level 2 grouping |

---

## Algoritma Rekonsiliasi

Hermes akan menjalankan urutan ini:

```
1. Baca semua sheet → dict of DataFrames
2. Identifikasi kolom kunci per sheet:
   - No Akun / Kode Rekening
   - Debit / Kredit
   - Jumlah / Saldo
   - No Referensi / Bukti
   - Tanggal
   - Keterangan
3. Quick compare: total per sheet → identifikasi sheet bermasalah
4. Group by akun: bandingkan per akun → identifikasi akun bermasalah
5. Transaction trace: untuk akun bermasalah, bandingkan per transaksi
6. Missing check: transaksi yang hanya muncul di satu sisi
7. Opening-closing bridge: saldo awal + mutasi = saldo akhir?
8. Generate report dengan highlight baris spesifik
```

---

## Output Laporan

```
═══════════════════════════════════════════════════════
  REKONSILIASI CROSS-SHEET: buku_besar.xlsx
  5 sheet, 2,340 transaksi
  Kamis, 29 Juni 2026
═══════════════════════════════════════════════════════

RINGKASAN SELISIH:
  Sheet 'Jurnal' vs 'Buku Besar'      : selisih 150,000
  Sheet 'Buku Besar' vs 'Neraca'      : selisih 150,000
  Sheet 'Neraca' vs 'Trial Balance'   : SEIMBANG

SUMBER SELISIH:
  ▸ Akun 103 (Kas) — selisih 150,000
    → Sheet 'Jurnal' baris 89: 20,000,000
    → Sheet 'Buku Besar' baris 89: 19,850,000
    → BEDA 150,000 — kemungkinan typo input
    → Direkomendasikan: cek dokumen sumber baris #89

  ▸ Akun 201 (Piutang) — 1 transaksi hilang
    → Sheet 'Jurnal' baris 112: 5,000,000 (Koreksi Bank)
    → Sheet 'Buku Besar': TIDAK DITEMUKAN
    → Direkomendasikan: posting jurnal #112 ke Buku Besar

  ▸ Akun 501 (Beban Admin) — 1 transaksi tanpa jurnal
    → Sheet 'Buku Besar' baris 201: 3,500,000
    → Sheet 'Jurnal': TIDAK DITEMUKAN
    → Direkomendasikan: buat jurnal untuk transaksi ini atau hapus dari BB

SALDO AWAL-AKHIR:
  Akun 103 (Kas):
    Saldo Awal 200,000,000 + Mutasi 20,000,000 = 220,000,000
    Saldo Akhir tercatat: 220,150,000 → SELISIH 150,000 ⚠

REKOMENDASI:
  1. Perbaiki nilai transaksi #89 di Buku Besar (atau Jurnal)
  2. Posting jurnal #112 ke Buku Besar
  3. Verifikasi transaksi #201 — buat jurnal atau hapus dari BB
  4. Setelah 3 koreksi di atas, selisih akan menjadi 0
═══════════════════════════════════════════════════════
```

---

## Tips untuk Hasil Maksimal

- **Sebutkan kolom kunci** kalau nama kolom tidak standar:
  "kolom akun namanya 'Kode GL', kolom jumlah 'Amount'"
- **Toleransi**: "abaikan selisih di bawah 100"
- **Sheet prioritas**: "sheet Jurnal adalah sumber kebenaran, sesuaikan yang lain"
- **File multi-periode**: "bandingkan saldo akhir Mei dengan saldo awal Juni"
- **Matching rule custom**: "cocokkan berdasarkan No Voucher, bukan No Akun"
- **Multi-file**: "rekonsiliasi jurnal_mei.xlsx dengan buku_besar_mei.xlsx"

---

## Error Patterns Found in Real Files

From actual GitHub accounting files (June 2026 audit):

### Pattern 1: Trial Balance Debit/Credit Swapped
**File:** Accounting_Clerk_Advanced.xlsx (Swift Tech Solutions)
**Symptom:** All Debit values in Credit column and vice versa
**Detection:** Compare Journal totals per account vs Trial Balance
**Example:**
```
Cash: Journal D=12,000 C=7,300 → TB D=7,300 C=12,000 (SWAPPED!)
Owner's Equity: Journal D=0 C=10,000 → TB D=10,000 C=0 (SWAPPED!)
```

### Pattern 2: Negative Owner's Equity
**File:** Accounting_Clerk_Advanced.xlsx
**Symptom:** Owner's Equity = -10,000 (should be +10,000)
**Impact:** Balance Sheet equation breaks: Assets 12,700 ≠ L+E -7,299.75
**Detection:** Check Balance Sheet equation

### Pattern 3: Missing Transaction Pair
**File:** SmartByte_Solutions.xlsx
**Symptom:** Only debit entry exists, no credit entry
**Detection:** Level 4 (Missing/Extra Transactions)

### Pattern 4: Ledger Incomplete
**File:** SmartByte_Solutions.xlsx  
**Symptom:** Ledger sheet only contains 1 account (Inventory)
**Detection:** Compare number of accounts in Journal vs Ledger

## Verifikasi yang Harus Dilakukan

1. **Journal vs Ledger**: Total Debit per akun harus sama
2. **Journal vs Trial Balance**: Saldo per akun harus sama
3. **Trial Balance**: Total Debit = Total Credit
4. **Balance Sheet**: Total Aset = Total Kewajiban + Ekuitas
5. **Income Statement**: Laba Bersih = Pendapatan - HPP - Beban

## Batasan

- Tidak bisa membaca file `.xlsb` (binary workbook)
- Formula Excel dibaca sebagai nilai (tidak dieksekusi ulang)
- Pencocokan transaksi berbasis teks — kalau deskripsi berbeda total ("Penjualan Tunai" vs "Penjualan Tunai ") bisa dianggap transaksi berbeda. Gunakan toleransi atau sebutkan aturan matching
- Performa: file dengan >100rb baris mungkin lambat — sebutkan sheet spesifik untuk audit

import hashlib, base64, secrets, yaml, os, sys

password = sys.argv[1]
salt = secrets.token_bytes(16)
dk = hashlib.scrypt(password.encode(), salt=salt, n=16384, r=8, p=1, dklen=32, maxmem=0)
password_hash = f"scrypt$16384$8$1${base64.b64encode(salt).decode()}${base64.b64encode(dk).decode()}"
secret = base64.b64encode(secrets.token_bytes(32)).decode()

home = os.environ["HOME"]
with open(f"{home}/.hermes/config.yaml") as f:
    config = yaml.safe_load(f)

config["dashboard"] = {
    "basic_auth": {
        "username": "admin",
        "password_hash": password_hash,
        "secret": secret,
    }
}

with open(f"{home}/.hermes/config.yaml", "w") as f:
    yaml.dump(config, f, default_flow_style=False, allow_unicode=True, sort_keys=False)

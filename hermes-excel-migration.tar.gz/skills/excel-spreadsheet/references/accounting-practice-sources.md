# Accounting Practice Excel Files — Sources

## GitHub Repositories (Verified June 2026)

### 1. mBrownepr1/excel-accounting-cycle ⭐ Best for audit practice
- File: `Accounting Clerk Advanced.xlsx` (37 KB)
- Sheets: Chart of Accounts, Journal Entry, Ledger, Trial Balance, Income Statement, Owner's Equity, Balance Sheet
- Company: Swift Tech Solutions
- Period: January 2025
- Transactions: 15+ entries covering owner investment, purchases, services on account, expenses
- Download: `curl -sL "https://raw.githubusercontent.com/mBrownepr1/excel-accounting-cycle/main/Accounting%20Clerk%20Advanced.xlsx" -o output.xlsx`

### 2. saqibsahto/Automated-Bookkeeping-System-Excel
- File 1: `Excel Bookkeeping with Free Template.xlsx` (89 KB)
  - Sheets: Settings, Bookkeeping (1000+ rows capacity), Summary Reports
  - Features: Auto-validation, category matching, date range checks
- File 2: `SmartByte Tech Solutions.xlsx` (32 KB)
  - Sheets: Charts of Account, General Entries, Ledger, Trial Balance, Income Statement, Balance Sheet
  - Company: SmartByte Tech Solutions, FY 2024
- Download: `curl -sL "https://raw.githubusercontent.com/saqibsahto/Automated-Bookkeeping-System-Excel/main/SmartByte%20Tech%20Solutions.xlsx" -o output.xlsx`

### 3. sadhanasrinivas/Accounting-Bookkeeping
- File: `CompanyAccounting.xlsx` (30 KB)
- Single comprehensive sheet with: General Journal, General Ledger, Adjusted Trial Balance, Financial Statements
- Company: Lemon LLC, FY 2021
- Features: Excel formulas linking journal → ledger → trial balance
- Download: `curl -sL "https://raw.githubusercontent.com/sadhanasrinivas/Accounting-Bookkeeping/main/CompanyAccounting.xlsx" -o output.xlsx`

### 4. pivotxl.com (Commercial templates)
- FV/PV Practice: `https://pivotxl.com/download/22103/` (49 KB)
- Sheets: Intro, FV_PV_Problems (22 Future Value / Present Value problems)
- Not accounting audit focused, but useful for finance students

## Search Command

```bash
curl -s "https://api.github.com/search/repositories?q=accounting+excel+journal+ledger&per_page=10"
```

Also try:
- `accounting+excel+template`
- `bookkeeping+excel+practice`
- `financial+statements+excel`

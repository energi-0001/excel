#!/bin/bash
set -e

RED="\033[1;31m"
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
CYAN="\033[1;36m"
NC="\033[0m"

echo "============================================"
echo "  Hermes + Excel + Dashboard Installer"
echo "  Public / Office Edition"
echo "============================================"
echo ""

# --- API key ---
if [ -z "$BYNARA_API_KEY" ]; then
    echo -e "${YELLOW}Masukkan BYNARA_API_KEY kamu:${NC}"
    read -r -p "> " BYNARA_API_KEY
    if [ -z "$BYNARA_API_KEY" ]; then
        echo -e "${RED}ERROR: API key tidak boleh kosong${NC}"
        exit 1
    fi
fi

# --- Step 1: Install Hermes ---
if command -v hermes &>/dev/null; then
    echo -e "${GREEN}[1/7]${NC} Hermes already installed: $(hermes --version 2>&1 | head -1)"
else
    echo "[1/7] Installing Hermes Agent..."
    curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash
    echo -e "${GREEN}[1/7] Hermes installed${NC}"
fi

export PATH=$HOME/.local/bin:$PATH

# --- Step 2: API key ---
echo "[2/7] Saving API key..."
printf "BYNARA_API_KEY=%s\n" "$BYNARA_API_KEY" >> ~/.hermes/.env
echo -e "${GREEN}[2/7] BYNARA_API_KEY saved${NC}"

# --- Step 3: Provider config ---
echo "[3/7] Configuring Bynara provider (25 models)..."
python3 << 'PYCONFIG'
import yaml, os
home = os.environ["HOME"]
with open(f"{home}/.hermes/config.yaml") as f:
    config = yaml.safe_load(f)
with open("custom_providers.yaml") as f:
    providers = yaml.safe_load(f)
config["custom_providers"] = providers
config["model"]["default"] = "mimo-v2.5-pro-hermes"
config["model"]["provider"] = "custom:bynara"
config["model"]["base_url"] = ""
config["model"]["key"] = ""
config["model"]["api_key"] = ""
config["model"]["model"] = ""
with open(f"{home}/.hermes/config.yaml", "w") as f:
    yaml.dump(config, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
PYCONFIG
echo -e "${GREEN}[3/7] Provider configured${NC}"

# --- Step 4: Skills ---
echo "[4/7] Installing Excel skills..."
mkdir -p ~/.hermes/skills/productivity
cp -r skills/excel-spreadsheet ~/.hermes/skills/productivity/excel-spreadsheet 2>/dev/null || true
cp -r skills/accounting-cross-sheet-recon ~/.hermes/skills/productivity/accounting-cross-sheet-recon 2>/dev/null || true
echo -e "${GREEN}[4/7] Skills: excel-spreadsheet, accounting-cross-sheet-recon${NC}"

# --- Step 5: Dashboard password ---
echo "[5/7] Generating dashboard password..."
DASH_PASSWORD=$(python3 -c "import secrets,string;print(''.join(secrets.choice(string.ascii_letters+string.digits)for _ in range(12)))")
python3 setup_dashboard.py "$DASH_PASSWORD"
echo -e "${GREEN}[5/7] Dashboard auth configured${NC}"

# --- Step 6: Systemd service ---
echo "[6/7] Installing dashboard as systemd service..."
mkdir -p ~/.config/systemd/user/

cat > ~/.config/systemd/user/hermes-dashboard.service << ENDUNIT
[Unit]
Description=Hermes Dashboard - Web UI
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=$HOME/.local/bin/hermes dashboard --host 0.0.0.0 --port 8080 --no-open --skip-build
Restart=always
RestartSec=10
Environment=PATH=$HOME/.local/bin:/usr/bin:/bin
Environment=HOME=$HOME

[Install]
WantedBy=default.target
ENDUNIT

systemctl --user daemon-reload
systemctl --user enable hermes-dashboard
systemctl --user start hermes-dashboard
sleep 3
echo -e "${GREEN}[6/7] Dashboard service installed & running${NC}"

# --- Step 7: Enable linger ---
echo "[7/7] Enabling user linger (survive logout)..."
sudo loginctl enable-linger $USER 2>/dev/null || true
echo -e "${GREEN}[7/7] Linger enabled${NC}"

# --- Summary ---
IP=$(hostname -I 2>/dev/null | awk '{print $1}' || echo "YOUR_VPS_IP")
echo ""
echo "============================================"
echo -e "  ${GREEN}INSTALL COMPLETE!${NC}"
echo "============================================"
echo ""
echo -e "  ${CYAN}Dashboard:${NC}  http://${IP}:8080"
echo -e "  Username:    admin"
echo -e "  Password:    ${YELLOW}${DASH_PASSWORD}${NC}"
echo ""
echo -e "  ${CYAN}CLI:${NC}        hermes"
echo -e "  ${CYAN}Skills:${NC}     excel-spreadsheet, accounting-cross-sheet-recon"
echo -e "  ${CYAN}Provider:${NC}   bynara (25 models)"
echo ""
echo -e "  ${RED}IMPORTANT:${NC} Save the password above!"
echo "============================================"

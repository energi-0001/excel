# Common Accounting Excel Sheet Structures

Reference for parsing Indonesian accounting Excel files (lengkap cycle).

## Standard Journal Sheet
Columns: `No | Tanggal | No Bukti | No Akun | Nama Akun | Keterangan | Debit | Kredit`
- Group by `No Bukti` for per-transaction Debit=Kredit check
- Compound entries: same description across multiple No Bukti values

## Trial Balance (Neraca Saldo)
Columns: `No Akun | Nama Akun | Debit | Kredit`
- Filter: only rows where No Akun is numeric (100-999)
- Stop at: "CATATAN AUDIT" section

## TB Setelah Penyesuaian (Adjusted TB)
Columns: `No Akun | Nama Akun | Saldo Sebelum | Penyesuaian Debit | Penyesuaian Kredit | Saldo Sesudah`
- NO standard Debit/Kredit header — `find_header()` returns None
- Parse directly by column index or column name
- `Saldo Sesudah` is the final balance (signed: negative = credit balance)

## Jurnal Penyesuaian (Adjusting Entries)
Columns: `No | Keterangan | No Akun | Nama Akun | Debit | Kredit`
- Header is at different row than journals
- Group by `No` (sequential number) for paired entries

## Laba Rugi (Income Statement)
Columns: `Keterangan | No Akun | Jumlah | Total`
- Line items have values in `Jumlah` column
- Summary rows (Total Pendapatan, Laba Kotor, Laba Bersih) have values in `Total` column
- Contra revenue (Retur Penjualan 405): listed UNDER revenue but must be SUBTRACTED

## Neraca (Balance Sheet)
Columns: `Keterangan | No Akun | Jumlah | Total`
- Negative values for contra assets (Akum Penyusutan shown as -7,000,000)
- Negative values for bank/inventory = red flag (not contra, but error)
- Summary rows use `Total` column

## Buku Besar (Ledger)
Multiple sheets by category: Aset, Kewajiban, Ekuitas, Pendapatan, Beban
Columns vary but typically: `Tanggal | Keterangan | Ref | Debit | Kredit | Saldo`
- Cross-check: sum of all ledger debits per account = sum of journal debits for same account

## Daftar Akun (Chart of Accounts)
Columns: `No Akun | Nama Akun | Kategori | Sub Kategori | Laporan Keuangan | Saldo Normal`
- Use for: verifying account classification, checking missing accounts in TB
- Saldo Normal: Debit or Kredit — determines which side increases the account

## Account Number Ranges (Indonesian GAAP)
| Range  | Category     | Normal Balance |
|--------|-------------|----------------|
| 100-199| Aset        | Debit (contra: Kredit) |
| 200-299| Kewajiban   | Kredit         |
| 300-399| Ekuitas     | Kredit (Prive 302: Debit) |
| 400-499| Pendapatan  | Kredit (Retur 405: Debit) |
| 500-599| HPP         | Debit          |
| 600-699| Beban       | Debit          |

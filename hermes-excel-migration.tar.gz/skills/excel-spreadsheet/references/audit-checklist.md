# Accounting Audit Checklist for Excel Files

Ordered by dependency (later checks depend on earlier ones).

## Level 1: Quick Sum Comparison
- [ ] Each journal quarter: Total Debit = Total Kredit
- [ ] Grand total all journals: Debit = Kredit
- [ ] Trial Balance: Total Debit = Total Kredit
- [ ] TB Setelah Penyesuaian: balanced

## Level 2: Account-Level Matching
- [ ] Compare journal totals per account vs ledger totals per account (must match)
- [ ] Compare TB balances vs ledger net balances (must match)
- [ ] Compare TB vs TB+Adj: identify which accounts changed from adjustments

## Level 3: Transaction-Level Tracing
- [ ] Per-transaction Debit=Kredit in each journal (group by No Bukti)
- [ ] Check for compound entries (split across multiple voucher numbers)
- [ ] Identify transactions with only debit or only credit (one-sided entries)

## Level 4: Financial Statement Verification

### Laba Rugi
- [ ] Total Pendapatan = sum(revenue) - Retur Penjualan (NOT +)
- [ ] Laba Kotor = Total Pendapatan - HPP
- [ ] Total Beban = sum(all expense accounts 601-616)
- [ ] Laba Bersih = Laba Kotor - Total Beban
- [ ] Cross-check each line item vs TB+Adj balance

### Neraca (Balance Sheet)
- [ ] Total Aset Lancar = sum(101-132 items)
- [ ] Total Aset Tetap = sum(141-147 items including contra)
- [ ] TOTAL ASET = Lancar + Tetap
- [ ] Total Kewajiban = sum(201-211)
- [ ] Total Ekuitas = Modal - Prive + Laba Bersih
- [ ] TOTAL K+L = Kewajiban + Ekuitas
- [ ] ASET = K+L (balance check)
- [ ] Laba Bersih in Neraca matches Laba Bersih in Laba Rugi

## Level 5: Red Flags
- [ ] Negative balances on accounts that shouldn't have them (Cash, Inventory, Receivables)
- [ ] Accounts in Daftar Akun but missing from TB (could indicate unrecorded transactions)
- [ ] Account classification errors (Aset Tetap listed as Aset Lancar)
- [ ] Suspense accounts or unexplained balancing entries
- [ ] Round numbers suggesting estimates rather than actual transactions

## Report Format
1. Ringkasan Eksekutif (summary with error count by severity)
2. Temuan per Sheet (detail with specific row/transaction references)
3. Tabel Koreksi (debit/credit correction entries needed)
4. Neraca Saldo Setelah Koreksi (corrected TB)
5. Verifikasi Laba Rugi Setelah Koreksi
6. Verifikasi Neraca Setelah Koreksi

## Severity Classification
- **MATERIAL**: affects net income, total assets, or balance sheet equation by >1%
- **SIGNIFIKAN**: classification errors, missing accounts, suspicious balances
- **IMMATERIAL**: rounding differences < 1 unit of currency

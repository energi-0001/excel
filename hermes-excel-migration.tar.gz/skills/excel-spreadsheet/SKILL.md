---
name: excel-spreadsheet
description: "Baca, tulis, edit file Excel (.xlsx, .xls, .csv) via Python openpyxl + pandas. Buat laporan, analisis data, pivot table, chart."
version: 1.0.0
metadata:
  hermes:
    tags: [excel, spreadsheet, xlsx, csv, data, pandas]
---

# Excel & Spreadsheet Skill

Skill ini mengajarkan Hermes cara bekerja dengan file Excel/CSV. Tidak ada tool khusus — Hermes menggunakan `execute_code` dengan Python + openpyxl/pandas.

## Cara Menggunakan

Cukup beri perintah natural, Hermes akan otomatis menulis dan menjalankan kode Python. Contoh:

```
"baca file data.xlsx dan tampilkan 10 baris pertama"
"tambah kolom 'total' = harga * qty di sales.xlsx"
"buat pivot table dari data.csv, group by category sum amount"
"export sheet 'Januari' ke CSV"
"buat chart bar dari kolom A dan B di laporan.xlsx"
"gabung semua sheet di workbook.xlsx jadi satu CSV"
"filter data.xlsx dimana status = 'active' simpan ke active.xlsx"
```

## Package yang Digunakan

Hermes akan otomatis install via `execute_code`:
- **openpyxl** — baca/tulis `.xlsx` (default)
- **pandas** — analisis data, pivot, group by, export multi-format
- **xlrd** — baca `.xls` (format lama)
- **csv** — built-in, untuk CSV

Tidak perlu install manual — Hermes akan `pip install` saat pertama kali dibutuhkan.

## Contoh Operasi

### Baca Excel
```python
import pandas as pd
df = pd.read_excel('data.xlsx', sheet_name='Sheet1')
print(df.head(10))
print(df.describe())
```

### Tulis Excel
```python
import pandas as pd
df = pd.DataFrame({'Nama': ['A', 'B'], 'Nilai': [90, 85]})
df.to_excel('output.xlsx', index=False)
```

### Edit (tambah kolom)
```python
import pandas as pd
df = pd.read_excel('data.xlsx')
df['Total'] = df['Harga'] * df['Qty']
df.to_excel('data.xlsx', index=False)
```

### Pivot Table
```python
import pandas as pd
df = pd.read_excel('data.xlsx')
pivot = df.pivot_table(values='Amount', index='Category', columns='Month', aggfunc='sum')
pivot.to_excel('pivot.xlsx')
```

### Chart
```python
import openpyxl
from openpyxl.chart import BarChart, Reference

wb = openpyxl.load_workbook('data.xlsx')
ws = wb.active

chart = BarChart()
data = Reference(ws, min_col=2, min_row=1, max_row=10, max_col=2)
chart.add_data(data, titles_from_data=True)
ws.add_chart(chart, 'E5')

wb.save('data.xlsx')
```

### Gabung CSV
```python
import pandas as pd
import glob

files = glob.glob('*.csv')
dfs = [pd.read_csv(f) for f in files]
merged = pd.concat(dfs, ignore_index=True)
merged.to_csv('gabungan.csv', index=False)
```

### Banyak Sheet
```python
import pandas as pd

# Lihat semua sheet
xls = pd.ExcelFile('workbook.xlsx')
print(xls.sheet_names)

# Baca sheet tertentu
df = pd.read_excel('workbook.xlsx', sheet_name='Data')

# Baca semua sheet → dict
all_sheets = pd.read_excel('workbook.xlsx', sheet_name=None)
for name, df in all_sheets.items():
    print(f"Sheet: {name} — {len(df)} rows")
```

## Tips

- **File path**: gunakan path relatif dari working directory atau path absolut
- **Sheet name**: kalau tidak disebutkan, Hermes akan baca sheet pertama
- **Backup**: sebelum edit besar, minta Hermes backup dulu: `cp data.xlsx data_backup.xlsx`
- **CSV encoding**: kalau karakter aneh, minta Hermes deteksi encoding: `encoding='utf-8-sig'` atau `encoding='latin1'`

## Audit Akuntansi Otomatis

Untuk menemukan ketidakseimbangan di laporan multi-sheet, gunakan perintah natural. Hermes akan menjalankan serangkaian pengecekan otomatis.

### Cara Memulai Audit

```
"audit laporan_keuangan.xlsx, cari semua ketidakseimbangan"
"periksa apakah neraca.xlsx balance: Assets = Liabilities + Equity"
"cross-check sheet Jurnal dan Buku Besar, cari selisih"
"verifikasi semua sheet di laporan.xlsx, tampilkan yang tidak cocok"
```

### Pengecekan yang Dilakukan Hermes (Otomatis)

#### 1. Balance Sheet Equation
Assets harus = Liabilities + Equity. Hermes akan mencari kolom yang mengandung "Asset", "Liabilit", "Equity", "Modal", "Kewajiban" dan memverifikasi persamaan.

```python
assets = df.loc[df['Kategori'].str.contains('Asset|Aset', case=False), 'Jumlah'].sum()
liabilities = df.loc[df['Kategori'].str.contains('Liabilit|Kewajiban|Hutang', case=False), 'Jumlah'].sum()
equity = df.loc[df['Kategori'].str.contains('Equity|Modal|Ekuitas', case=False), 'Jumlah'].sum()
selisih = assets - (liabilities + equity)
# selisih harus 0 (atau mendekati 0 untuk toleransi pembulatan)
```

#### 2. Cross-Sheet Reconciliation
Membandingkan total dari sheet yang seharusnya sama. Contoh: total Debit di Jurnal harus = total Debit di Buku Besar.

```python
# Baca semua sheet
sheets = pd.read_excel('laporan.xlsx', sheet_name=None)

# Bandingkan total antar sheet
for name1, df1 in sheets.items():
    for name2, df2 in sheets.items():
        if name1 < name2:
            total1 = df1.select_dtypes(include='number').sum().sum()
            total2 = df2.select_dtypes(include='number').sum().sum()
            if abs(total1 - total2) > 0.01:
                print(f"SELISIH: {name1} vs {name2} → {total1 - total2:,.2f}")
```

#### 3. Debit = Kredit
Setiap sheet dengan kolom Debit/Kredit harus balance.

```python
debit = df['Debit'].sum() if 'Debit' in df.columns else 0
kredit = df['Kredit'].sum() if 'Kredit' in df.columns else 0
if abs(debit - kredit) > 0.01:
    print(f"SELISIH Debit-Kredit: {debit - kredit:,.2f}")
```

#### 4. Hierarchical Sum Check
Jika ada kolom kategori dengan sub-kategori, Hermes akan mengecek apakah total anak = total induk. Contoh: "Kas + Bank" harus = "Total Aset Lancar".

```python
# Cek: total subkategori = total kategori induk
# Hermes mendeteksi pola "Total X" dan menjumlahkan item di bawahnya
```

#### 5. Duplicate Detection
Mencari baris duplikat (no referensi ganda, transaksi identik).

```python
dupes = df[df.duplicated(subset=['No_Ref', 'Tanggal', 'Jumlah'], keep=False)]
if len(dupes) > 0:
    print(f"DUPLIKAT: {len(dupes)} baris — cek manual")
    print(dupes.to_string())
```

#### 6. Missing/Orphan References
Cek apakah semua ID referensi di satu sheet muncul di sheet lain.

```python
refs_sheet1 = set(df1['No_Akun'].dropna().unique())
refs_sheet2 = set(df2['No_Akun'].dropna().unique())
missing = refs_sheet1 - refs_sheet2
if missing:
    print(f"MISSING REF: {len(missing)} akun di sheet1 tidak ada di sheet2")
```

#### 7. Rounding Discrepancy
Mendeteksi selisih kecil akibat pembulatan (biasanya < 1.0).

```python
if 0 < abs(selisih) < 1.0:
    print(f"ROUNDING: selisih {selisih:.4f} — kemungkinan pembulatan")
```

#### 8. Outlier Detection
Nilai yang jauh di luar distribusi normal (mungkin salah input).

```python
q1 = df['Jumlah'].quantile(0.25)
q3 = df['Jumlah'].quantile(0.75)
iqr = q3 - q1
outliers = df[(df['Jumlah'] < q1 - 1.5*iqr) | (df['Jumlah'] > q3 + 1.5*iqr)]
```

### Output Audit

Hermes akan menghasilkan laporan seperti ini:

```
═══════════════════════════════════════════
  AUDIT: laporan_keuangan.xlsx
   6 sheet dianalisis
═══════════════════════════════════════════

✓ Balance Sheet: SEIMBANG (Assets = Liabilities + Equity)
   Assets: 1,250,000,000 | Liab+Equity: 1,250,000,000

✗ Sheet 'Jurnal': DEBIT ≠ KREDIT
   Debit: 450,000,000 | Kredit: 449,850,000
   Selisih: 150,000 → lihat baris 234-236

✗ Cross-Check: 'Jurnal' vs 'Buku Besar'
   Jurnal total: 899,850,000 | Buku Besar: 899,700,000
   Selisih: 150,000 — 3 transaksi tidak ditemukan di Buku Besar

⚠ Duplikat: 2 baris di sheet 'Penjualan'
   Baris 45 & 89: No_Ref INV-2026-045 muncul 2x

⚠ Rounding: selisih 0.03 di Neraca (pembulatan)

═══════════════════════════════════════════
  RINGKASAN: 2 error, 2 warning
═══════════════════════════════════════════
```

### Tips Audit Accounting

- **Sebutkan aturan**: "Debit=Kredit di sheet Jurnal" atau "total sheet A = total sheet B"
- **Toleransi**: sebutkan jika ada toleransi pembulatan: "cari selisih di atas 1000"
- **Multi-file**: "bandingkan neraca_bulan_ini.xlsx dengan neraca_bulan_lalu.xlsx"
- **Sheet spesifik**: kalau banyak sheet, sebutkan mana yang utama: "audit sheet Neraca dan Laba Rugi saja"
- **Tambah logika**: "kalau selisih < 100 anggap rounding error"

### Command Cepat

| Perintah | Fungsi |
|----------|--------|
| `audit <file>` | Audit lengkap: balance sheet, cross-sheet, debit=kredit, duplikat, missing ref |
| `cek balance <file>` | Hanya cek Assets = Liabilities + Equity |
| `cek cross <file>` | Hanya cek cross-sheet reconciliation |
| `cek duplikat <file>` | Hanya cari duplikat |
| `bandingkan <file1> <file2>` | Bandingkan dua file (month-over-month) |
| `cek koneksi antar sheet <file>` | Cari orphan reference antar sheet |

## Pitfalls

### Sheet Structure Detection (Critical for Audit)

Not all sheets use standard "Debit/Kredit" columns. Common variants:

1. **TB Setelah Penyesuaian** may use: `No Akun, Nama Akun, Saldo Sebelum, Penyesuaian Debit, Penyesuaian Kredit, Saldo Sesudah` — NO standard Debit/Kredit header. The `find_header()` pattern (searching for 'Debit' and 'Kredit') will return None.

2. **Laba Rugi / Neraca** typically use: `Keterangan, No Akun, Jumlah, Total` — "Jumlah" for line items, "Total" for subtotals/summaries.

3. **Trailing notes sections**: Most sheets end with "CATATAN AUDIT" followed by guidelines text. ALWAYS filter these out by stopping row iteration when:
   - `No Akun` is NaN or non-numeric
   - Keterangan contains "CATATAN AUDIT" or "Poin Verifikasi"
   - Values are all NaN

**Robust header detection pattern:**
```python
def find_header(df):
    for i, row in df.iterrows():
        vals = [str(v).strip() for v in row.values if pd.notna(v)]
        if 'Debit' in vals and 'Kredit' in vals:
            return i
    return None  # Handle None explicitly — sheet may have non-standard structure

def get_clean_data(df, header_row):
    """Get data after header, stop at CATATAN AUDIT."""
    data = df.iloc[header_row+1:].copy()
    data.columns = [str(c).strip() for c in df.iloc[header_row].values]
    # Stop at trailing notes
    cutoff = None
    for i, row in data.iterrows():
        vals = [str(v).strip() for v in row.values]
        if any('CATATAN' in v or 'Poin Verifikasi' in v for v in vals):
            cutoff = i
            break
    if cutoff is not None:
        data = data.loc[:cutoff-1]
    data = data.reset_index(drop=True)
    for c in ['Debit', 'Kredit']:
        if c in data.columns:
            data[c] = pd.to_numeric(data[c], errors='coerce').fillna(0)
    return data
```

### Contra Accounts in Audit

When verifying Debit=Kredit or balance sheet equations, handle contra accounts by sign:
- **Contra assets** (Akum. Penyusutan 143/145/147, Cad. Kerugian Piutang 113): credit balance → negate when summing assets
- **Contra revenue** (Retur Penjualan 405): debit balance → SUBTRACT from total revenue, don't add
- **Contra equity** (Prive 302): debit balance → subtract from equity

Common bug: Retur Penjualan listed under "Pendapatan" but added instead of subtracted in Total Pendapatan calculation. Always verify:
```python
correct_total_pendapatan = sum(revenue_items) - retur_penjualan  # NOT +
```

### Negative Balance Detection

Flag accounts with negative balances that shouldn't have them:
- **Cash/Bank** (101-103): negative = missing receipts or posting error (unless formal overdraft exists)
- **Inventory** (121-122): negative = physically impossible — HPP overcounted or receipts missing
- **Receivables** (111): negative = overpayment or posting error

### Compound Journal Entries

Some transactions span multiple journal voucher numbers (e.g., JU-003 + JU-004 for a single purchase). When checking per-transaction Debit=Kredit:
- Group by transaction DESCRIPTION/Keterangan, not just No Bukti
- If two vouchers share the same description and date, check if they balance when combined
- Don't immediately flag as error — check compound pattern first

### Script Execution Fallback

When `execute_code` fails with heredoc issues (ampersands, special chars in SQL-like data), fall back to `write_file` + `terminal`:
1. Write Python script to `/tmp/audit_*.py` via `write_file`
2. Run via `terminal(command="cd /path && source venv/bin/activate && python3 /tmp/script.py")`
This avoids heredoc escaping problems entirely.

### Python Environment Setup (Critical)

On modern Debian/Ubuntu systems, `pip` is not available by default (PEP 668). The `execute_code` sandbox may also lack pip. Follow this pattern:

```bash
# 1. Install python3-venv (one-time, needs sudo)
sudo apt install -y python3-pip python3-venv

# 2. Create virtual environment
python3 -m venv ~/accounting-practice/venv

# 3. Activate and install
source ~/accounting-practice/venv/bin/activate
pip install openpyxl pandas
```

If `execute_code` fails with `No module named pip` or `No module named ensurepip`, fall back to `terminal()` with the venv pattern above. Never assume openpyxl is pre-installed.

### Finding Accounting Practice Files

When the user asks for accounting Excel practice files, search GitHub:

```bash
curl -s "https://api.github.com/search/repositories?q=accounting+excel+journal+ledger&per_page=10"
```

Known good repos (as of June 2026):
- `mBrownepr1/excel-accounting-cycle` — "Accounting Clerk Advanced.xlsx" (7 sheets: Chart of Accounts, Journal, Ledger, Trial Balance, Income Statement, Owner's Equity, Balance Sheet)
- `saqibsahto/Automated-Bookkeeping-System-Excel` — "Bookkeeping_Template.xlsx" + "SmartByte_Solutions.xlsx" (6 sheets each)
- `sadhanasrinivas/Accounting-Bookkeeping` — "CompanyAccounting.xlsx" (journal + ledger + trial balance with formulas)

Download pattern:
```bash
curl -sL "https://raw.githubusercontent.com/{owner}/{repo}/main/{filename}" -o "output.xlsx"
```

Use URL encoding for filenames with spaces: `%20` for space.

## References

- `references/accounting-practice-sources.md` — GitHub repos and download links for accounting practice Excel files (journal, ledger, trial balance, financial statements).
- `references/accounting-sheet-structures.md` — Common column structures for each sheet type (Jurnal, TB, Laba Rugi, Neraca, etc.) and how to parse them robustly.
- `references/audit-checklist.md` — 5-level audit checklist with cross-verification steps and report format template.

## Keterbatasan

- Tidak bisa edit file `.xlsb` (binary workbook)
- Formula Excel tidak tereksekusi — hanya nilai yang terbaca
- Chart terbatas pada yang didukung openpyxl (bar, line, pie, scatter, area)

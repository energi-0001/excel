#!/bin/bash
set -e

RED="\033[1;31m"
GREEN="\033[1;32m"
YELLOW="\033[1;33m"
NC="\033[0m"

echo "============================================"
echo "  Hermes Migration Package Installer"
echo "  Excel + Bynara (Public/Office Edition)"
echo "============================================"
echo ""

# Cek API key
if [ -z "$BYNARA_API_KEY" ]; then
    echo -e "${YELLOW}Masukkan BYNARA_API_KEY kamu:${NC}"
    read -r -p "> " BYNARA_API_KEY
    if [ -z "$BYNARA_API_KEY" ]; then
        echo -e "${RED}ERROR: API key tidak boleh kosong${NC}"
        exit 1
    fi
fi

# Step 1: Install Hermes
if command -v hermes &>/dev/null; then
    echo -e "${GREEN}[✓]${NC} Hermes already installed: $(hermes --version 2>&1 | head -1)"
else
    echo "[1/5] Installing Hermes Agent..."
    curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash
    export PATH=$HOME/.local/bin:$PATH
    echo -e "${GREEN}[✓]${NC} Hermes installed"
fi

export PATH=$HOME/.local/bin:$PATH

# Step 2: Simpan API key ke .env
echo "[2/5] Saving Bynara API key..."
printf "BYNARA_API_KEY=%s\n" "$BYNARA_API_KEY" >> ~/.hermes/.env
echo -e "${GREEN}[✓]${NC} BYNARA_API_KEY saved to ~/.hermes/.env"

# Step 3: Merge custom_providers config
echo "[3/5] Configuring custom provider..."
python3 -c "
import yaml

with open(\"$HOME/.hermes/config.yaml\") as f:
    config = yaml.safe_load(f)

with open(\"custom_providers.yaml\") as f:
    providers = yaml.safe_load(f)

config[\"custom_providers\"] = providers
config[\"model\"][\"default\"] = \"mimo-v2.5-pro-hermes\"
config[\"model\"][\"provider\"] = \"custom:bynara\"
config[\"model\"][\"base_url\"] = \"\"
config[\"model\"][\"key\"] = \"\"
config[\"model\"][\"api_key\"] = \"\"
config[\"model\"][\"model\"] = \"\"

with open(\"$HOME/.hermes/config.yaml\", \"w\") as f:
    yaml.dump(config, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
print(\"Config updated — 1 provider, 25 models\")
"
echo -e "${GREEN}[✓]${NC} Provider config updated"

# Step 4: Copy skills
echo "[4/5] Installing Excel skills..."
mkdir -p ~/.hermes/skills/productivity
cp -r skills/excel-spreadsheet ~/.hermes/skills/productivity/excel-spreadsheet 2>/dev/null || true
cp -r skills/accounting-cross-sheet-recon ~/.hermes/skills/productivity/accounting-cross-sheet-recon 2>/dev/null || true
echo -e "${GREEN}[✓]${NC} Skills: excel-spreadsheet, accounting-cross-sheet-recon"

# Step 5: Verify
echo "[5/5] Verifying..."
echo ""
echo "  Hermes: $(hermes --version 2>&1 | head -1)"
echo "  Provider: custom:bynara"
echo "  Models: $(grep -c "^  - " custom_providers.yaml) model"
echo "  Skills:"
ls ~/.hermes/skills/productivity/excel-spreadsheet/SKILL.md 2>/dev/null && echo "    ✓ excel-spreadsheet" || echo "    ✗ excel-spreadsheet MISSING"
ls ~/.hermes/skills/productivity/accounting-cross-sheet-recon/SKILL.md 2>/dev/null && echo "    ✓ accounting-cross-sheet-recon" || echo "    ✗ accounting-cross-sheet-recon MISSING"
echo ""
echo "============================================"
echo "  DONE! Run: hermes"
echo "============================================"
